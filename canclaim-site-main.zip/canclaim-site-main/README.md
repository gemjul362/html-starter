# Proyecto CanClaim MVP

## Instrucciones rápidas

1. Abre una terminal en esta carpeta.
2. Ejecuta: `npm install`
3. Luego: `npm run dev`
4. Abre `index.html` con Live Server

Si Tailwind no compila correctamente, usa este comando directo en Windows:
```
.
ode_modules\.bin	ailwindcss.cmd -i ./src/input.css -o ./dist/output.css --watch
```

Este proyecto está preconfigurado para arrancar con un solo comando.
